# Unit 3 Lesson 24 — Build a class skeleton

Run `GamePiece` before editing and record the baseline. Complete the TODOs in the starter source, compile every Java file, then run `GamePieceCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one contract or debugging explanation. Do not edit the Check file.

