public class GamePiece {
    private int x;
    private int y;

    public GamePiece(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        // TODO
        return 0;
    }

    public int getY() {
        // TODO
        return 0;
    }

    public void move(int dx, int dy) {
        // TODO
    }

    public static void main(String[] args) {
        GamePiece piece = new GamePiece(2, 3);
        System.out.println(piece.getX() + "," + piece.getY());
    }
}

