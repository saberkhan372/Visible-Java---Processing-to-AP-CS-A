public class GamePieceCheck {
    private static int passed;
    private static int total;

    private static void check(String label, boolean condition) {
        total++;
        if (condition) {
            passed++;
            System.out.println("PASS: " + label);
        } else {
            System.out.println("REVISE: " + label);
        }
    }

    public static void main(String[] args) throws Exception {
        java.lang.reflect.Field x = GamePiece.class.getDeclaredField("x");
        java.lang.reflect.Field y = GamePiece.class.getDeclaredField("y");
        check("x is private", java.lang.reflect.Modifier.isPrivate(x.getModifiers()));
        check("y is private", java.lang.reflect.Modifier.isPrivate(y.getModifiers()));
        GamePiece piece = new GamePiece(2, 3);
        check("x accessor", piece.getX() == 2);
        check("y accessor", piece.getY() == 3);
        piece.move(4, -2);
        check("x movement", piece.getX() == 6);
        check("y movement", piece.getY() == 1);
        System.out.println(passed + " of " + total + " checks passed");
        if (passed != total) System.exit(1);
    }
}

