public class ClassDesign {
    public static String ownerOf(String responsibility) {
        // TODO: return "model" or "interface".
        return "undecided";
    }

    public static void main(String[] args) {
        System.out.println(ownerOf("change score"));
        System.out.println(ownerOf("draw score"));
    }
}

