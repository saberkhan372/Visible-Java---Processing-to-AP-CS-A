# Unit 3 Lesson 30 — Share state with static

Run `Ticket` before editing and record the baseline. Complete the TODOs in the starter source, compile every Java file, then run `TicketCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one contract or debugging explanation. Do not edit the Check file.

