public class PasswordRuleCheck {
    private static int passed;
    private static int total;

    private static void check(String label, boolean condition) {
        total++;
        if (condition) {
            passed++;
            System.out.println("PASS: " + label);
        } else {
            System.out.println("REVISE: " + label);
        }
    }

    public static void main(String[] args) throws Exception {
        PasswordRule rule = new PasswordRule(8);
        check("constructor value", rule.getMinimumLength() == 8);
        rule.setMinimumLength(12);
        check("valid mutation", rule.getMinimumLength() == 12);
        rule.setMinimumLength(0);
        check("zero ignored", rule.getMinimumLength() == 12);
        rule.setMinimumLength(-4);
        check("negative ignored", rule.getMinimumLength() == 12);
        check("toString contract", rule.toString().equals("minimum length: 12"));
        check("constructor repairs zero", new PasswordRule(0).getMinimumLength() == 1);
        check("constructor repairs negative", new PasswordRule(-3).getMinimumLength() == 1);
        check("instances independent", new PasswordRule(5).getMinimumLength() == 5);
        System.out.println(passed + " of " + total + " checks passed");
        if (passed != total) System.exit(1);
    }
}

