public class PasswordRule {
    private int minimumLength;

    public PasswordRule(int minimumLength) {
        this.minimumLength = Math.max(1, minimumLength);
    }

    public int getMinimumLength() {
        // TODO
        return 0;
    }

    public void setMinimumLength(int value) {
        // TODO: accept positive values only.
    }

    public String toString() {
        return "unfinished";
    }

    public static void main(String[] args) {
        PasswordRule rule = new PasswordRule(8);
        System.out.println("minimum " + rule.getMinimumLength());
        System.out.println(rule);
    }
}

