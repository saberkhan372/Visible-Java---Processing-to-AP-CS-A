# Unit 3 Lesson 25 — Construct a valid object

Run `Bicycle` before editing and record the baseline. Complete the TODOs in the starter source, compile every Java file, then run `BicycleCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one contract or debugging explanation. Do not edit the Check file.

