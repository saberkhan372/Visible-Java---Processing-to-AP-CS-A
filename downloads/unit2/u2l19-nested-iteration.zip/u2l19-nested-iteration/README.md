# Unit 2 Lesson 19 — Nested iteration

Before coding, match each loop variable to the part of the output it controls. Complete the
staircase and factor-pair methods, then run `PatternLabCheck`.
