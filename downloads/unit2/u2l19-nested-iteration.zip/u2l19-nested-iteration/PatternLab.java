public class PatternLab {
    public static String staircase(int size) {
        // For size 3, return "***\n-**\n--*".
        return "";
    }

    public static int countFactorPairs(int limit) {
        // Count ordered pairs (a, b) with 1 <= a <= b <= limit
        // for which a * b is divisible by 6.
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(staircase(5));
        System.out.println(countFactorPairs(5));
    }
}
