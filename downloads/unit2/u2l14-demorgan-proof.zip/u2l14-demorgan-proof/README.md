# Unit 2 Lesson 14 — Prove a Boolean equivalence

Complete `BooleanLab`, then run `BooleanLabCheck`. The check class evaluates all four truth-table
rows for two Boolean inputs. Your written evidence explains why negating `&&` changes it to `||`.
