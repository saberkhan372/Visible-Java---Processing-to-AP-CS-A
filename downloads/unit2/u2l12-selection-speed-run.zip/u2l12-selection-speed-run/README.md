# Unit 2 Lesson 12 — Selection speed-run

Run `DecisionAudit` first. The starter compiles and prints placeholder behavior.

Then complete `classify` and `inRange`. Compile `DecisionAudit.java` and
`DecisionAuditCheck.java`, then run `DecisionAuditCheck`.

Required evidence: all checks pass, one boundary-case explanation, and the lesson-page AP transfer.
