public class StringScan {
    public static int countCharacter(String text, String target) {
        // Precondition: target.length() == 1
        return 0;
    }

    public static int firstIndexOf(String text, String target) {
        // Precondition: target.length() == 1
        // Return -1 when target does not occur.
        return -1;
    }

    public static void main(String[] args) {
        System.out.println(countCharacter("banana", "a"));
        System.out.println(firstIndexOf("banana", "n"));
    }
}
