# Unit 2 Lesson 17 — Scan a String safely

Complete both methods using one-character substrings. The final legal index is
`text.length() - 1`, so the loop condition must keep `i + 1` in bounds. Run `StringScanCheck`.
