# Unit 2 Lesson 13 — Compound decisions

Run `Admission` before editing. Complete the ordered `if` chain and the compound Boolean expression.

Compile `Admission.java` and `AdmissionCheck.java`, then run `AdmissionCheck`. Pay special attention
to age 12, age 65, and a minor who has only one of the two required conditions.
