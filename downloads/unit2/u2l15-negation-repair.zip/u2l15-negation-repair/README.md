# Unit 2 Lesson 15 — Negation repair shop

Run the starter and notice that `notWeekend(7)` is wrong. Repair all three methods without adding
nested `if` statements. Compile both Java files and run `EligibilityCheck`.
