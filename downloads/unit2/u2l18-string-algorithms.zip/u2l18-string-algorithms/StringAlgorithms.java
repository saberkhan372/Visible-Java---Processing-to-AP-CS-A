public class StringAlgorithms {
    public static String removeCharacter(String text, String target) {
        // Precondition: target.length() == 1
        return "";
    }

    public static int countDouble(String text, String target) {
        // Precondition: target.length() == 1
        // Count non-overlapping pairs such as "aa".
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(removeCharacter("banana", "a"));
        System.out.println(countDouble("baaaad", "a"));
    }
}
