# Unit 2 Lesson 18 — Build and test String algorithms

Complete `removeCharacter` and `countDouble`. The second method counts non-overlapping pairs:
`"aaaa"` contains two counted pairs. Run `StringAlgorithmsCheck`, then add one test of your own.
