# Unit 2 Lesson 20 — Count executions, not milliseconds

Predict each method's result for `n = 5` before editing. Complete the loops, run
`RuntimeLabCheck`, and describe each growth pattern as constant, linear, or quadratic-scale
without using a stopwatch.
