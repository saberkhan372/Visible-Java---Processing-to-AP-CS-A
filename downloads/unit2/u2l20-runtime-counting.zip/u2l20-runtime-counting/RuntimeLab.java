public class RuntimeLab {
    public static int linearCount(int n) {
        int count = 0;
        // TODO: use one loop whose body executes n times.
        return count;
    }

    public static int triangularCount(int n) {
        int count = 0;
        // TODO: nested loops where the inner loop executes row times.
        return count;
    }

    public static int squareCount(int n) {
        int count = 0;
        // TODO: nested loops where both loops execute n times.
        return count;
    }

    public static void main(String[] args) {
        System.out.println(linearCount(5));
        System.out.println(triangularCount(5));
        System.out.println(squareCount(5));
    }
}
