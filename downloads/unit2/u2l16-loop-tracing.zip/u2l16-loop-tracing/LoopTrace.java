public class LoopTrace {
    public static int sumTo(int n) {
        // Precondition: n >= 0
        // TODO: use a while loop to return 1 + 2 + ... + n.
        return 0;
    }

    public static int countBy(int start, int stop, int step) {
        // Preconditions: start <= stop and step > 0
        // TODO: return the number of values printed by start, start + step, ... <= stop.
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(sumTo(5));
        System.out.println(countBy(2, 10, 2));
    }
}
