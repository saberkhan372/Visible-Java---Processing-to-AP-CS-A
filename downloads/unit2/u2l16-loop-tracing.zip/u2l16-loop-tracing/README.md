# Unit 2 Lesson 16 — Trace the loop before writing it

Create a trace table for each baseline call before editing. Complete one `while` loop and one
`for` loop, then run `LoopTraceCheck`. Your evidence must include the final trace row for
`countBy(1, 8, 2)`.
