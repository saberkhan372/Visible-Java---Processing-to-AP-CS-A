public class ArrayTraversal {
    public static int sum(int[] values) {
        // TODO
        return 0;
    }

    public static int countPositive(int[] values) {
        // TODO: zero is not positive.
        return 0;
    }

    public static void main(String[] args) {
        int[] values = {-2, 0, 5, 7};
        System.out.println(sum(values));
        System.out.println(countPositive(values));
    }
}

