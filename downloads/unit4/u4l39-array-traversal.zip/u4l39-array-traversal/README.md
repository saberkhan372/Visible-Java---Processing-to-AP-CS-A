# Unit 4 Lesson 39 — Traverse exactly once

Run `ArrayTraversal` before editing and record the baseline. Complete the TODOs, compile all Java files, then run `ArrayTraversalCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary or invariant explanation. Do not edit the Check file.

