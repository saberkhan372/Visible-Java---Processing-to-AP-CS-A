# Unit 4 Lesson 55 — Trace row-major traversal

Run the baseline, complete the TODOs, and compare every check. Compile all Java files, then run `GridTraversalCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary, invariant, or call-stack explanation. Do not edit the Check file.

