public class GradebookValidatorCheck {
    private static int passed, total;
    private static void check(String label, boolean ok) {
        total++;
        if (ok) { passed++; System.out.println("PASS: " + label); }
        else System.out.println("REVISE: " + label);
    }
    public static void main(String[] args) throws Exception {
        check("zero valid", GradebookValidator.isValidRecord("Sam,0"));
        check("one hundred valid", GradebookValidator.isValidRecord("Ada,100"));
        check("negative invalid", !GradebookValidator.isValidRecord("Lin,-1"));
        check("above range invalid", !GradebookValidator.isValidRecord("Lin,101"));
        check("empty name invalid", !GradebookValidator.isValidRecord(",82"));
        check("extra field invalid", !GradebookValidator.isValidRecord("A,80,note"));
        java.nio.file.Path file = java.nio.file.Files.createTempFile("grades", ".txt");
        java.nio.file.Files.writeString(file, "Ada,100\n,82\nLin,101\nSam,0\n");
        check("file valid count", GradebookValidator.countValid(file.toString()) == 2);
        java.nio.file.Path empty = java.nio.file.Files.createTempFile("grades-empty", ".txt");
        check("empty file", GradebookValidator.countValid(empty.toString()) == 0);
        java.nio.file.Files.deleteIfExists(file);
        java.nio.file.Files.deleteIfExists(empty);
        System.out.println(passed + " of " + total + " checks passed");
        if (passed != total) System.exit(1);
    }
}

