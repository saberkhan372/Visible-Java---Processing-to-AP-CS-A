import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GradebookValidator {
    public static boolean isValidRecord(String record) {
        // TODO: require name,score and an inclusive score from 0 to 100.
        return false;
    }

    public static int countValid(String path) throws FileNotFoundException {
        Scanner input = new Scanner(new File(path));
        int count = 0;
        // TODO
        input.close();
        return count;
    }

    public static void main(String[] args) throws FileNotFoundException {
        int valid = countValid("grades.txt");
        System.out.println("valid: " + valid);
        System.out.println("invalid: " + (4 - valid));
    }
}

