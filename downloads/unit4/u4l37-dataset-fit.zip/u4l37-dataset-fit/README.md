# Unit 4 Lesson 37 — Match data to a question

Run `DatasetFit` before editing and record the baseline. Complete the TODOs, compile all Java files, then run `DatasetFitCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary or invariant explanation. Do not edit the Check file.

