# Unit 4 Lesson 42 — Shift without overwriting

Run `ArrayShift` before editing and record the baseline. Complete the TODOs, compile all Java files, then run `ArrayShiftCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary or invariant explanation. Do not edit the Check file.

