# Unit 4 Lesson 41 — Build the array algorithm toolkit

Run `ArrayAlgorithms` before editing and record the baseline. Complete the TODOs, compile all Java files, then run `ArrayAlgorithmsCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary or invariant explanation. Do not edit the Check file.

