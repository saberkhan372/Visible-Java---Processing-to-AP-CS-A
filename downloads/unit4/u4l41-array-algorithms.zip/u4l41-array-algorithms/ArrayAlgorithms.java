public class ArrayAlgorithms {
    public static int minimum(int[] values) {
        // Precondition: values.length > 0
        return 0;
    }

    public static int countMatches(int[] values, int target) {
        // TODO
        return 0;
    }

    public static void main(String[] args) {
        int[] values = {8, 3, 3, 10};
        System.out.println(minimum(values));
        System.out.println(countMatches(values, 3));
    }
}

