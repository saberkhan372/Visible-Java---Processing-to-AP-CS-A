# Unit 4 Lesson 48 — Cross the wrapper boundary

Run `WrapperLab` from this project folder and record the baseline. Complete the TODOs, compile all Java files, then run `WrapperLabCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one parsing, boundary, or index-shift explanation. Do not edit the Check file.

