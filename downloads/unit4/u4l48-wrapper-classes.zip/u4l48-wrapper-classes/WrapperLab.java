public class WrapperLab {
    public static int roundTrip(int value) {
        Integer boxed = value;
        // TODO: return the primitive value.
        return 0;
    }

    public static int addTextNumbers(String first, String second) {
        // Precondition: both Strings represent ints.
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(Integer.parseInt("42"));
        System.out.println(roundTrip(7));
    }
}

