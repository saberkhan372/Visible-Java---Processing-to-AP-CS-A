# Unit 4 Lesson 50 — Traverse a changing-size collection

Run `ListTraversal` from this project folder and record the baseline. Complete the TODOs, compile all Java files, then run `ListTraversalCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one parsing, boundary, or index-shift explanation. Do not edit the Check file.

