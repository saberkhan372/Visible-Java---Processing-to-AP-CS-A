# Unit 4 Lesson 64 — Trace recursion without writing it

Predict every trace before running the complete program. Compile all Java files, then run `RecursionTraceCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary, invariant, or call-stack explanation. Do not edit the Check file.

