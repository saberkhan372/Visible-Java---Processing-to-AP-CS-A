# Unit 4 Lesson 40 — Know the enhanced-for limit

Run `ForEachLimits` before editing and record the baseline. Complete the TODOs, compile all Java files, then run `ForEachLimitsCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary or invariant explanation. Do not edit the Check file.

