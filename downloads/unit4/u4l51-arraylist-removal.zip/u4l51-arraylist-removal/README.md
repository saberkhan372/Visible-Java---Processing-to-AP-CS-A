# Unit 4 Lesson 51 — Remove without skipping

Run `ListRemoval` from this project folder and record the baseline. Complete the TODOs, compile all Java files, then run `ListRemovalCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one parsing, boundary, or index-shift explanation. Do not edit the Check file.

