# Unit 4 Lesson 65 — Trace recursive search and merge sort

Predict every trace before running the complete program. Compile all Java files, then run `RecursiveAlgorithmsCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary, invariant, or call-stack explanation. Do not edit the Check file.

