# Unit 4 Lesson 44 — Read tokens with File and Scanner

Run `TokenReader` from this project folder and record the baseline. Complete the TODOs, compile all Java files, then run `TokenReaderCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one parsing, boundary, or index-shift explanation. Do not edit the Check file.

