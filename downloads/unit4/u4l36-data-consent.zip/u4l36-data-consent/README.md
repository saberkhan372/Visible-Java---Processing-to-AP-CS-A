# Unit 4 Lesson 36 — Audit a data decision

Run `DataConsent` before editing and record the baseline. Complete the TODOs, compile all Java files, then run `DataConsentCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary or invariant explanation. Do not edit the Check file.

