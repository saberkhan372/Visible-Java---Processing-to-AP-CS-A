# Unit 4 Lesson 46 — Weather Data Analyzer

Run `WeatherData` from this project folder and record the baseline. Complete the TODOs, compile all Java files, then run `WeatherDataCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one parsing, boundary, or index-shift explanation. Do not edit the Check file.

