# Unit 4 Lesson 45 — Inventory Auditor

Run `InventoryAudit` from this project folder and record the baseline. Complete the TODOs, compile all Java files, then run `InventoryAuditCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one parsing, boundary, or index-shift explanation. Do not edit the Check file.

