# Unit 4 Lesson 63 — Trace sorting invariants

Run the baseline, complete the TODOs, and compare every check. Compile all Java files, then run `SortTraceCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary, invariant, or call-stack explanation. Do not edit the Check file.

