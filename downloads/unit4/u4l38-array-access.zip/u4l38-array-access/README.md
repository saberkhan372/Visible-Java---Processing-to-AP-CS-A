# Unit 4 Lesson 38 — Create and index arrays safely

Run `ArrayAccess` before editing and record the baseline. Complete the TODOs, compile all Java files, then run `ArrayAccessCheck`.

Required evidence: all checks pass, the lesson-page AP transfer, and one boundary or invariant explanation. Do not edit the Check file.

