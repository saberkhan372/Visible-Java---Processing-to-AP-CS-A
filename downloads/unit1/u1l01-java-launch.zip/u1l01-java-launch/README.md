# Unit 1 Lesson 1 — Leave the PDE deliberately

Compile `JavaLaunch.java` and `JavaLaunchCheck.java` together. Run `JavaLaunch` first and record
the unchanged baseline. Then complete `greeting` and `lineCount` without renaming the public class.

Run `JavaLaunchCheck` when you are ready. Required evidence: four passing checks, one compiler
message caused by an intentional class/file mismatch, and the lesson-page AP transfer.
