public class JavaLaunch {
    public static String greeting() {
        // TODO: return the course name exactly.
        return "unfinished";
    }

    public static int lineCount() {
        // TODO: main prints two lines.
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(greeting());
        System.out.println(lineCount());
    }
}
