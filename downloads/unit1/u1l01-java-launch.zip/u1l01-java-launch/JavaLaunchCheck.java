import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class JavaLaunchCheck {
    private static int passed = 0;
    private static int total = 0;

    private static void check(String label, Object expected, Object actual) {
        total++;
        if (expected.equals(actual)) {
            passed++;
            System.out.println("PASS: " + label);
        } else {
            System.out.println("REVISE: " + label + " (expected " + expected + ", got " + actual + ")");
        }
    }

    public static void main(String[] args) throws Exception {
        check("course greeting", "AP Computer Science A", JavaLaunch.greeting());
        check("main prints two lines", 2, JavaLaunch.lineCount());
        check("public class name", "JavaLaunch", JavaLaunch.class.getSimpleName());
        Method main = JavaLaunch.class.getMethod("main", String[].class);
        check("main is static", true, Modifier.isStatic(main.getModifiers()));
        System.out.println(passed + " of " + total + " checks passed");
        if (passed != total) System.exit(1);
    }
}
