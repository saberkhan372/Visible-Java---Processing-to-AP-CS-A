public class WordTools {
    public static String firstWord(String text) {
        // TODO: return the whole String when no space exists.
        return "";
    }

    public static String safeSlice(String text, int start, int end) {
        // Return "invalid" for illegal bounds. Otherwise return the substring.
        return "";
    }

    public static void main(String[] args) {
        System.out.println(firstWord("rain catcher game"));
        System.out.println(safeSlice("computer", 2, 5));
    }
}
