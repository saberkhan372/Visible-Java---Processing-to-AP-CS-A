# Unit 1 Lesson 7 — Index a String safely

Run the blank baseline, draw an index row for each test String, then complete `firstWord` and
`safeSlice`. Interpret `indexOf` before using its result as a substring boundary.

Run `WordToolsCheck`. Required evidence: seven passing checks and one index diagram showing why an
exclusive end may equal `length()`.
