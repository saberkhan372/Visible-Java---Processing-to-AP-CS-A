# Unit 1 Lesson 3 — Control a random range

Test the range arithmetic with known samples before using `Math.random()`. Complete
`scaleSample`, then make `roll` call it. Do not change either precondition or method header.

Run `DiceLabCheck`. Required evidence: seven passing checks and an interval explanation for why a
sample below 1.0 may produce `max`, while a sample equal to 1.0 would be invalid.
