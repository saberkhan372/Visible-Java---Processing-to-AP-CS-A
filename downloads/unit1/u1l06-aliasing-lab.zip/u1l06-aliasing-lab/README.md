# Unit 1 Lesson 6 — Trace references and aliases

`Player.java` is complete and required; do not edit it. Complete the three methods in
`AliasingLab.java`, then run `AliasingCheck`. Use `TRACE.md` for the arrow diagram.

Required evidence: six passing checks, the four-line object trace, and an explanation of why Java
can pass references by value while a method still mutates the caller's object.
