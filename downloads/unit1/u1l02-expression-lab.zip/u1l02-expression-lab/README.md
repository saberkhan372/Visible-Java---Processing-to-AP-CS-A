# Unit 1 Lesson 2 — Make numeric types visible

Run `ExpressionLab` unchanged and record each output's value and type. Repair `average`,
`wholePart`, and `remainder` without changing their method headers.

Compile both Java files and run `ExpressionLabCheck`. Required evidence: seven passing checks and
an explanation of why assigning `7 / 2` to a `double` cannot restore the fraction.
