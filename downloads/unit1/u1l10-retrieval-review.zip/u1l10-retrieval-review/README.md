# Unit 1 Lesson 10 — Retrieve, diagnose, target

Do not repair methods from top to bottom. First predict all six results without running. Then run
`Unit1ReviewCheck`, label each miss by skill, and repair the two weakest categories first.

Required evidence: six passing checks, one named error pattern, and one targeted next practice step.
Do not copy secure AP Classroom question text into this project or the public workbook.
