public class Player {
    private String name;
    private int score;

    public Player(String startName, int startScore) {
        // TODO: initialize both fields from the parameters.
        name = "unknown";
        score = 0;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public void addScore(int amount) {
        // TODO: update this Player's score.
    }
}
