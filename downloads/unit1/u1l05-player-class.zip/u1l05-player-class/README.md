# Unit 1 Lesson 5 — Build an object with valid state

This is a two-class project. Edit `Player.java`; use `PlayerDemo.java` to create and run two
objects. Keep the fields private and keep each public class in its matching file.

Run `PlayerCheck`. Required evidence: seven passing checks and a diagram showing the state of both
objects after construction and after `ada.addScore(3)`.
