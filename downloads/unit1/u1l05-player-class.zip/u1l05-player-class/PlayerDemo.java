public class PlayerDemo {
    public static void main(String[] args) {
        Player ada = new Player("Ada", 4);
        Player grace = new Player("Grace", 12);
        System.out.println(ada.getName() + " " + ada.getScore());
        System.out.println(grace.getName() + " " + grace.getScore());
    }
}
