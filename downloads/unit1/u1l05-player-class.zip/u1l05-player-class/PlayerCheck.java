public class PlayerCheck {
    private static int passed = 0;
    private static int total = 0;

    private static void check(String label, Object expected, Object actual) {
        total++;
        if (expected.equals(actual)) {
            passed++;
            System.out.println("PASS: " + label);
        } else {
            System.out.println("REVISE: " + label + " (expected " + expected + ", got " + actual + ")");
        }
    }

    public static void main(String[] args) {
        Player ada = new Player("Ada", 4);
        Player grace = new Player("Grace", 12);
        check("first name", "Ada", ada.getName());
        check("first starting score", 4, ada.getScore());
        check("second name", "Grace", grace.getName());
        check("second starting score", 12, grace.getScore());
        ada.addScore(3);
        check("add positive score", 7, ada.getScore());
        ada.addScore(0);
        check("add zero", 7, ada.getScore());
        check("objects keep independent state", 12, grace.getScore());
        System.out.println(passed + " of " + total + " checks passed");
        if (passed != total) System.exit(1);
    }
}
