# Unit 1 Lesson 8 — Compare String contents

The unchanged starter intentionally uses `==` for a content question. Record the baseline, then
complete `sameText` and normalize the sign of `compareTo` in `order`.

Run `StringRelationsCheck`. Required evidence: eight passing checks and a one-sentence distinction
among `==`, `equals`, and `compareTo`. `split` and `Integer.parseInt` remain a Unit 4 preview.
