public class GeometryCheck {
    private static int passed = 0;
    private static int total = 0;

    private static void check(String label, double expected, double actual) {
        total++;
        if (Math.abs(expected - actual) < 0.0000001) {
            passed++;
            System.out.println("PASS: " + label);
        } else {
            System.out.println("REVISE: " + label + " (expected " + expected + ", got " + actual + ")");
        }
    }

    public static void main(String[] args) {
        check("horizontal distance", 5.0, Geometry.distance(1, 2, 6, 2));
        check("vertical distance", 7.0, Geometry.distance(3, -2, 3, 5));
        check("3-4-5 triangle", 5.0, Geometry.distance(0, 0, 3, 4));
        check("reverse direction", 5.0, Geometry.distance(3, 4, 0, 0));
        check("zero distance", 0.0, Geometry.distance(2, 2, 2, 2));
        check("origin overload", 13.0, Geometry.distance(5, 12));
        System.out.println(passed + " of " + total + " checks passed");
        if (passed != total) System.exit(1);
    }
}
