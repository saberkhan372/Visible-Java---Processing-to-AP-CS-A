# Unit 1 Lesson 4 — Honor the method contract

Complete both `distance` methods without changing either header. The two-parameter overload must
call the four-parameter overload instead of repeating the distance formula.

Run `GeometryCheck`. Required evidence: six passing checks and an explanation of why return type
alone cannot distinguish overloaded methods.
