public class Geometry {
    public static double distance(double x1, double y1, double x2, double y2) {
        // TODO: preserve this required header.
        return 0.0;
    }

    public static double distance(double x, double y) {
        // TODO: delegate to the four-parameter overload.
        return 0.0;
    }

    public static void main(String[] args) {
        System.out.println(distance(0, 0, 3, 4));
        System.out.println(distance(3, 4));
    }
}
