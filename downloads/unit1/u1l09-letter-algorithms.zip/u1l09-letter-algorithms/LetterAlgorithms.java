public class LetterAlgorithms {
    /** Precondition: target.length() == 1 */
    public static int countLetter(String text, String target) {
        // TODO: inspect one-character substrings.
        return 0;
    }

    /** Precondition: target.length() == 1 */
    public static String removeLetter(String text, String target) {
        // TODO: build and return a new String.
        return "";
    }

    public static void main(String[] args) {
        System.out.println(countLetter("banana", "a"));
        System.out.println(removeLetter("banana", "a"));
    }
}
