# Unit 1 Lesson 9 — Build a one-pass String algorithm

Before editing, write the legal `i` values for each check String and state what the accumulator
means. Complete `countLetter` and `removeLetter` using one-character substrings.

Run `LetterAlgorithmsCheck`. Required evidence: eight passing checks, one original boundary case,
and the loop invariant for each accumulator.
